(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_[locale]_layout_tsx_2e705528._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_[locale]_layout_tsx_2e705528._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_9df9d490._.js",
    "static/chunks/src_components_AuthProvider_jsx_13c1ef76._.js",
    "static/chunks/[root of the server]__e0f99016._.css"
  ],
  "source": "dynamic"
});
