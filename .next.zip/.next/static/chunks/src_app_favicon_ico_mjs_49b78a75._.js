(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_favicon_ico_mjs_49b78a75._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_favicon_ico_mjs_49b78a75._.js",
  "chunks": [
    "static/chunks/670a6_next_dist_c335f00d._.js"
  ],
  "source": "dynamic"
});
