(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_[locale]_error_tsx_8be73b13._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_[locale]_error_tsx_8be73b13._.js",
  "chunks": [
    "static/chunks/src_app_[locale]_error_tsx_284b83ae._.js"
  ],
  "source": "dynamic"
});
