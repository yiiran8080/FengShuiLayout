__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root of the server]__94722535._.js",
  "static/chunks/a14e7_react-dom_638ad3bb._.js",
  "static/chunks/node_modules__pnpm_cf23c0c8._.js",
  "static/chunks/[root of the server]__49fd8634._.js",
  "static/chunks/pages__app_5771e187._.js",
  "static/chunks/pages__app_60bd3dcb._.js"
])
