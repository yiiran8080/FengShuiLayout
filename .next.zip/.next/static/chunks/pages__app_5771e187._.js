(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__app_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__app_5771e187._.js",
  "chunks": [
    "static/chunks/[root of the server]__94722535._.js",
    "static/chunks/a14e7_react-dom_638ad3bb._.js",
    "static/chunks/node_modules__pnpm_cf23c0c8._.js",
    "static/chunks/[root of the server]__49fd8634._.js"
  ],
  "source": "entry"
});
