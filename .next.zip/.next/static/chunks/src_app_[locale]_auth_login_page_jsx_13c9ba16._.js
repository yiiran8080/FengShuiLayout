(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_[locale]_auth_login_page_jsx_13c9ba16._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_[locale]_auth_login_page_jsx_13c9ba16._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f57c0391._.js",
    "static/chunks/src_003289ab._.js",
    "static/chunks/node_modules__pnpm_1aae981a._.js"
  ],
  "source": "dynamic"
});
