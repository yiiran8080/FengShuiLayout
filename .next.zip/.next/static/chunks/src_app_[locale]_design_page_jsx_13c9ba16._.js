(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_[locale]_design_page_jsx_13c9ba16._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_[locale]_design_page_jsx_13c9ba16._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c17362f9._.js",
    "static/chunks/src_b4e4ca1e._.js",
    "static/chunks/43146_@dnd-kit_core_dist_core_esm_a3578c96.js",
    "static/chunks/670a6_next_e9e29581._.js",
    "static/chunks/971da_lodash_lodash_dd68795c.js",
    "static/chunks/e0945_@radix-ui_react-select_dist_index_mjs_c5ccb9ab._.js",
    "static/chunks/node_modules__pnpm_d42b03b0._.js",
    "static/chunks/_8776be25._.css"
  ],
  "source": "dynamic"
});
