(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_[locale]_page_tsx_8be73b13._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_[locale]_page_tsx_8be73b13._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_6e3d8ca1._.js",
    "static/chunks/src_f5473233._.js",
    "static/chunks/670a6_next_c325e4e8._.js",
    "static/chunks/e0945_@radix-ui_react-select_dist_index_mjs_c5ccb9ab._.js",
    "static/chunks/node_modules__pnpm_4ef5fd15._.js"
  ],
  "source": "dynamic"
});
