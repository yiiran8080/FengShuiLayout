(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d32._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d32._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c36aaf62._.js",
    "static/chunks/670a6_next_dist_compiled_a0414a2b._.js",
    "static/chunks/670a6_next_dist_client_8b027f6a._.js",
    "static/chunks/670a6_next_dist_040b82a4._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
  ],
  "source": "entry"
});
