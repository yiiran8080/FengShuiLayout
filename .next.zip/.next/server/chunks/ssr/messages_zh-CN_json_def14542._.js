module.exports = {

"[project]/messages/zh-CN.json (json)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v(JSON.parse("{\"Index\":{\"title\":\"风水布局\",\"description\":\"为您的空间带来和谐\"},\"Navigation\":{\"cn\":\"简体中文\",\"tw\":\"繁体中文\"},\"home\":{\"hero\":{\"title\":\"打造和谐风水布局\",\"title2\":\"融合自然之力，优化气场流动\",\"subtitle\":\"新年新气象，一步实现365天好运\",\"cta\":\"免费开始测算\",\"login\":\"登录\",\"logout\":\"登出\",\"locale\":\"语言切换\",\"home\":\"首页\"},\"features\":{\"title1\":\"准确度高 用户称心满意\",\"subtitle1\":\"配合住户八字，辅以流年九宫飞星图、家居方位等进行分析，并参考10万+案例，用户能量运势增强\",\"title2\":\"24-7自助定制化服务\",\"subtitle2\":\"随时随地，1分钟即可免费获取专业风水谘询。只需输入家居平面图和简单个人资料，操作简单方便\",\"title3\":\"市场一折价格 退款保障\",\"subtitle3\":\"划一价HKD$888，获得加强版风水报告，包括每月的调整方案。新张期内follow Instagram获得迎新码即享低至每平方呎HKD$1优惠，2025年6月30日前购买更享退款保障*。\"},\"share\":{\"title\":\"分享您的平面图\",\"description\":\"绘制平面图，使用我们的交互工具拖放来可视化您的空间\",\"cta\":\"立即开始\"},\"compare\":{\"title\":\"HarmoniQ洞见\",\"description\":\"获取个性化风水见解，按照我们的建议打造完美平衡的生活空间\",\"cta\":\"定制化风水报告\",\"before\":\"测算前\",\"after\":\"测算后\"}},\"design\":{\"rooms\":\"房间\",\"furniture\":\"家具\",\"items\":{\"livingRoom\":\"客厅\",\"bedroom\":\"卧室\",\"door\":\"门\",\"window\":\"窗\",\"bed\":\"床\",\"sofa\":\"沙发\",\"table\":\"桌子\"},\"showTab\":\"选择房间或家具\",\"cta\":\"开始测算\"}}"));}}),

};