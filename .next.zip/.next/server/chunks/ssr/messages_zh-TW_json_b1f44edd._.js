module.exports = {

"[project]/messages/zh-TW.json (json)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v(JSON.parse("{\"Index\":{\"title\":\"風水佈局\",\"description\":\"為您的空間帶來和諧\"},\"Navigation\":{\"design\":\"設計佈局\",\"login\":\"登入\",\"register\":\"註冊\"},\"home\":{\"hero\":{\"title\":\"風水佈局設計\",\"subtitle\":\"為您的空間帶來和諧與平衡\",\"description\":\"通過專業的風水佈局設計，讓您的居住或工作空間充滿正能量，提升生活品質。\",\"cta\":\"開始設計\"},\"features\":{\"title\":\"特色功能\",\"subtitle\":\"運用現代科技，傳承傳統智慧，為您打造完美居所\"}},\"design\":{\"rooms\":\"房間\",\"furniture\":\"家具\",\"items\":{\"livingRoom\":\"客廳\",\"bedroom\":\"臥室\",\"door\":\"門\",\"window\":\"窗\",\"bed\":\"床\",\"sofa\":\"沙發\",\"table\":\"桌子\"},\"showTab\":\"选择房间或家具\",\"cta\":\"开始测算\"}}"));}}),

};